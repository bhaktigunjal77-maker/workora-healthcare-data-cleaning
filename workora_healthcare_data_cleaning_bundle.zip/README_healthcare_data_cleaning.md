# Healthcare Patient Data Cleaning and Analysis

## Files
- `healthcare_patients_clean.csv`: cleaned dataset.
- `healthcare_data_analysis.xlsx`: workbook with clean data, quality checks, missing-value counts, range checks, and descriptive summaries.
- `clean_healthcare_data.py`: reproducible Python script.

## Findings for the supplied dataset
- 600 rows and 11 columns.
- No missing cells found.
- No duplicate PatientID values found.
- No out-of-range values found under the screening rules in the script.
- The supplied file does **not** contain `DateOfBirth`, blood-pressure, or dosage columns. It contains `Age`; therefore those requested conversions cannot be performed without a different/source dataset containing those fields. No missing columns or values were fabricated.

## Run the Python script
Install dependencies:
```bash
pip install pandas openpyxl
```
Put `healthcare_patients_v2.csv` beside `clean_healthcare_data.py`, then run:
```bash
python clean_healthcare_data.py
```

## Create a public submission link using GitHub
1. Sign in to GitHub and create a new repository (e.g. `workora-healthcare-data-cleaning`).
2. Choose **Public** visibility.
3. Upload `healthcare_patients_clean.csv`, `healthcare_data_analysis.xlsx`, `clean_healthcare_data.py`, and this README.
4. Open each uploaded file and copy its URL, or copy the repository URL to submit all files together.
5. Verify the link in a private/incognito browser window while signed out.

If the dataset contains real patient information, do not make it public. This supplied file appears to use synthetic IDs, but confirm it contains no identifiable personal/clinical information before public upload.
