"""
Healthcare patient dataset cleaning and descriptive analysis
Usage:
    python clean_healthcare_data.py
Requirements:
    pandas, openpyxl
Place this script in the same folder as healthcare_patients_v2.csv.
It creates healthcare_patients_clean.csv and healthcare_data_analysis.xlsx.
"""
from pathlib import Path
import pandas as pd
import numpy as np

INPUT_FILE = "healthcare_patients_v2.csv"
CLEAN_FILE = "healthcare_patients_clean.csv"
REPORT_FILE = "healthcare_data_analysis.xlsx"

# Plausible bounds used for screening. Adapt to the data dictionary/local policy.
RANGE_RULES = {
    "Age": (0, 120),
    "ComorbidityCount": (0, 50),
    "PriorAdmissions12M": (0, 100),
    "LengthOfStayDays": (0, 3650),
}

def main():
    input_path = Path(INPUT_FILE)
    if not input_path.exists():
        raise FileNotFoundError(
            f"Cannot find {INPUT_FILE}. Put it in the same folder as this script."
        )

    source = pd.read_csv(input_path, dtype={"PatientID": "string"})
    data = source.copy()

    # Trim text values and convert numeric attributes where present.
    for col in data.select_dtypes(include=["object", "string"]).columns:
        data[col] = data[col].astype("string").str.strip()

    for col in ["Age", "ComorbidityCount", "PriorAdmissions12M", "LengthOfStayDays"]:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")

    # The supplied file has Age but does NOT contain DateOfBirth, BloodPressure,
    # or Dosage. Do not invent those fields or infer values that were not supplied.
    missing_by_col = data.isna().sum().rename("MissingCount").reset_index()
    missing_by_col.columns = ["Column", "MissingCount"]

    duplicate_rows = data[data["PatientID"].duplicated(keep=False)] if "PatientID" in data.columns else data.iloc[0:0]
    duplicate_count = int(duplicate_rows.shape[0])

    range_results = []
    for col, (lower, upper) in RANGE_RULES.items():
        if col in data.columns:
            invalid = data[col].notna() & ((data[col] < lower) | (data[col] > upper))
            range_results.append({
                "Metric": col,
                "AllowedMinimum": lower,
                "AllowedMaximum": upper,
                "OutOfRangeCount": int(invalid.sum()),
            })
    range_checks = pd.DataFrame(range_results)

    # Resolve duplicate PatientID records by keeping the first occurrence.
    # This dataset contains no duplicate IDs, so no rows are removed.
    if "PatientID" in data.columns:
        data = data.drop_duplicates(subset=["PatientID"], keep="first")

    data.to_csv(CLEAN_FILE, index=False)

    numeric_columns = data.select_dtypes(include=np.number).columns.tolist()
    categorical_columns = data.select_dtypes(include=["object", "string", "category"]).columns.tolist()
    numeric_summary = data[numeric_columns].describe().T.reset_index().rename(columns={"index": "Attribute"})

    categorical_rows = []
    for col in categorical_columns:
        counts = data[col].value_counts(dropna=False)
        categorical_rows.append({
            "Attribute": col,
            "UniqueValues": int(data[col].nunique(dropna=True)),
            "MostFrequentCategory": str(counts.index[0]) if len(counts) else "",
            "MostFrequentCount": int(counts.iloc[0]) if len(counts) else 0,
            "MissingCount": int(data[col].isna().sum()),
        })
    categorical_summary = pd.DataFrame(categorical_rows)

    findings = pd.DataFrame([
        {"Check": "Rows in source dataset", "Result": len(source), "Interpretation": "Number of records loaded."},
        {"Check": "Rows in cleaned dataset", "Result": len(data), "Interpretation": "Records after duplicate-ID handling."},
        {"Check": "Missing values (all columns)", "Result": int(source.isna().sum().sum()), "Interpretation": "Missing cells detected in source."},
        {"Check": "Duplicate PatientID rows", "Result": duplicate_count, "Interpretation": "Rows belonging to repeated PatientID values."},
        {"Check": "Out-of-range values (defined rules)", "Result": int(range_checks["OutOfRangeCount"].sum()) if not range_checks.empty else 0,
         "Interpretation": "Count under documented screening bounds."},
        {"Check": "DateOfBirth conversion", "Result": "Not applicable", "Interpretation": "DateOfBirth column is absent; Age is supplied instead."},
        {"Check": "Blood pressure conversion", "Result": "Not applicable", "Interpretation": "No blood-pressure column is present."},
        {"Check": "Dosage conversion", "Result": "Not applicable", "Interpretation": "No dosage column is present."},
    ])

    with pd.ExcelWriter(REPORT_FILE, engine="openpyxl") as writer:
        data.to_excel(writer, sheet_name="Clean Dataset", index=False)
        findings.to_excel(writer, sheet_name="Data Quality Checks", index=False)
        missing_by_col.to_excel(writer, sheet_name="Missing Values", index=False)
        range_checks.to_excel(writer, sheet_name="Range Checks", index=False)
        numeric_summary.to_excel(writer, sheet_name="Numerical Summary", index=False)
        categorical_summary.to_excel(writer, sheet_name="Categorical Summary", index=False)
        if not duplicate_rows.empty:
            duplicate_rows.to_excel(writer, sheet_name="Duplicate Patient IDs", index=False)

    print(f"Saved cleaned dataset: {CLEAN_FILE}")
    print(f"Saved analysis workbook: {REPORT_FILE}")
    print(f"Source rows: {len(source)} | Clean rows: {len(data)}")
    print(f"Missing cells: {int(source.isna().sum().sum())}")
    print(f"Duplicate PatientID rows: {duplicate_count}")
    print(f"Out-of-range values: {int(range_checks['OutOfRangeCount'].sum()) if not range_checks.empty else 0}")

if __name__ == "__main__":
    main()
